package com.campusledger.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;
    private String serverUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF14284B);
        serverUrl = getString(R.string.server_url);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true); // keeps the sign-in session

        final String host = Uri.parse(serverUrl).getHost();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (host != null && host.equals(u.getHost())) return false;   // stay inside the app
                startActivity(new Intent(Intent.ACTION_VIEW, u));              // everything else opens the browser
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showMessage("Can't connect",
                        "Check your internet connection, then try again.");
            }
        });

        // Lets the page's "Print or save as PDF" button open Android's print dialog.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void print() {
                runOnUiThread(() -> {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    pm.print("Campus Ledger receipt",
                            web.createPrintDocumentAdapter("Campus Ledger receipt"),
                            new PrintAttributes.Builder().build());
                });
            }
        }, "Android");

        if (serverUrl.contains("YOUR-APP")) {
            showMessage("Server address not set",
                    "Open app/build.gradle.kts, set serverUrl to your server's address, and rebuild the app.");
        } else {
            web.loadUrl(serverUrl);
        }
    }

    private void showMessage(String title, String body) {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;background:#14284b;color:#fff;text-align:center;padding:12vh 24px'>"
                + "<h2>" + title + "</h2><p style='opacity:.85'>" + body + "</p>"
                + (serverUrl.contains("YOUR-APP") ? "" :
                   "<p><a href='" + serverUrl + "' style='color:#f2b43a;font-size:18px'>Try again</a></p>")
                + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush(); // save the session cookie to disk
    }

    // Back button: close a pop-up, then return to Overview, then exit.
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack ? window.appBack() : false", value -> {
            if (!"true".equals(value)) {
                MainActivity.super.onBackPressed();
            }
        });
    }
}
