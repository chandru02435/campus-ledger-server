plugins {
    id("com.android.application")
}

// >>> Put your server address here, then rebuild. <<<
//   Real phone / production:   "https://your-app.onrender.com"
//   Emulator talking to a server on your own computer:   "http://10.0.2.2:3000"
val serverUrl = "https://YOUR-APP.onrender.com"

android {
    namespace = "com.campusledger.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.campusledger.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
        resValue("string", "server_url", serverUrl)
    }

    buildFeatures {
        resValues = true
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
