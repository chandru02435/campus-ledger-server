# Campus Ledger (Android)

A thin app that opens your Campus Ledger server inside a WebView. All data, logins and rules
live on the server, so admins and students can use different phones.

## Before you build
1. Deploy the server (see campus-ledger-server/README.md) and note its address, for example https://campus-ledger.onrender.com
2. Open app/build.gradle.kts and set `serverUrl` to that address.

## Build the APK
1. Install Android Studio (Koala or newer).
2. File > Open, choose this CampusLedger folder, wait for Gradle sync (first sync needs internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Open app/build/outputs/apk/debug/app-debug.apk, copy it to a phone and install it
   (allow "install unknown apps" when asked). Requires Android 8.0+.

## Testing against your own computer
Run the server locally (port 3000), set `serverUrl = "http://10.0.2.2:3000"`, and run the app in the Android emulator.
Plain http is allowed only for that address; everything else must be https.
